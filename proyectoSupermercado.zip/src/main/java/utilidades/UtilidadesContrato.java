package utilidades;

public class UtilidadesContrato {
}
