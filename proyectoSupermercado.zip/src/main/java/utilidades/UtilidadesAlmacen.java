package utilidades;

public class UtilidadesAlmacen {
}
