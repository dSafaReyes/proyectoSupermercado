package utilidades;

public class UtilidadesEmpleado {
}
