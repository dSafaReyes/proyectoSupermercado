package modelos;

public enum TipoContrato {

    PRACTICAS, TEMPORAL, OBRAYSERVICIO, INDEFINIDO

}
