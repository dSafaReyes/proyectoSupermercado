package modelos;

public enum TipoCliente {

    PARTICULAR, EMPRESA

}
